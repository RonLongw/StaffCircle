﻿using System;
using System.Diagnostics;
using Xunit;
using RepositoryCore.Repositories;
using RepositoryCore.Model;
using RepositoryCore.DataAccessLayer;
using Microsoft.EntityFrameworkCore;

namespace RepositoryCoreTests
{
    public class TwilioTests
    {
        private string conn = "Data Source=DESKTOP-IPPVKT1\\SQLEXPRESS;Initial Catalog=SMS;Integrated Security=True;Connect Timeout=30;Encrypt=False;";

        //private string conn = "Server = DESKTOP-IPPVKT1\\SQLEXPRESS; Database = SMS; Trusted_Connection = True; ";

        //[Fact]
        //public void InsertSmsMessageThrowsException()
        //{
        //    var optionsBuilder = new DbContextOptionsBuilder<SmsDbContext>();
        //    optionsBuilder.UseSqlServer(conn);

        //    var sms = new SmsDbContext(optionsBuilder.Options);
        //}

        [Fact]
        public void InsertTwilioAccount()
        {
            var optionsBuilder = new DbContextOptionsBuilder<SmsDbContext>();
            optionsBuilder.UseSqlServer(conn);

            var twilio = new TwilioAccount()
            {
                AccountSid = "qla77277277272",
                AuthToken = "ajjsjjdjdjdjdj",
                Created = DateTime.Now,
                Expired = null              
            };

            var context = new SmsDbContext(optionsBuilder.Options);

            var repository = new EFTwilioAccountsRepository(context);
            var result = repository.Add(twilio);

            Debug.WriteLine($"Result Value: {result}");

            Assert.True(result > 0);
        }

        [Fact]
        public void InsertTwilioMessageWithNoAccountSid()
        {
            var optionsBuilder = new DbContextOptionsBuilder<SmsDbContext>();
            optionsBuilder.UseSqlServer(conn);

            var twilio = new TwilioAccount()
            {
                AccountSid = "",
                AuthToken = "ls8829393993399",
                Created = DateTime.Now,
                Expired = null
            };

            var context = new SmsDbContext(optionsBuilder.Options);

            var repository = new EFTwilioAccountsRepository(context);
            var result = repository.Add(twilio);

            Debug.WriteLine($"Result Value: {result}");

            Assert.True(result == 0);
        }

        [Fact]
        public void InsertTwilioMessageWithNoAuthToken()
        {
            var optionsBuilder = new DbContextOptionsBuilder<SmsDbContext>();
            optionsBuilder.UseSqlServer(conn);

            var twilio = new TwilioAccount()
            {
                AccountSid = "qkka888829292929",
                AuthToken = "",
                Created = DateTime.Now,
                Expired = null
            };

            var context = new SmsDbContext(optionsBuilder.Options);

            var repository = new EFTwilioAccountsRepository(context);
            var result = repository.Add(twilio);

            Debug.WriteLine($"Result Value: {result}");

            Assert.True(result == 0);
        }

        [Fact]
        public void InsertTwilioMessageWithDateNotSet()
        {
            var optionsBuilder = new DbContextOptionsBuilder<SmsDbContext>();
            optionsBuilder.UseSqlServer(conn);

            var twilio = new TwilioAccount()
            {
                AccountSid = "",
                AuthToken = "",
                //Created = DateTime.Now,
                Expired = null
            };

            var context = new SmsDbContext(optionsBuilder.Options);

            var repository = new EFTwilioAccountsRepository(context);
            var result = repository.Add(twilio);

            Debug.WriteLine($"Result Value: {result}");

            Assert.True(result == 0);
        }

        [Fact]
        public void GetTwilioAccount()
        {
            var optionsBuilder = new DbContextOptionsBuilder<SmsDbContext>();
            optionsBuilder.UseSqlServer(conn);

            var context = new SmsDbContext(optionsBuilder.Options);

            var repository = new EFTwilioAccountsRepository(context);
            var result = repository.Find(s => s.Id == 1);

            if (result != null)
            {
                var TwilioId = result.Id;

                Assert.True(TwilioId == 1);
            }
            else
            {
                Assert.False(result.Id != 1);
            }

        }

        [Fact]
        public void GetTwilioAccounts()
        {
            var optionsBuilder = new DbContextOptionsBuilder<SmsDbContext>();
            optionsBuilder.UseSqlServer(conn);

            var context = new SmsDbContext(optionsBuilder.Options);

            var repository = new EFTwilioAccountsRepository(context);
            var result = repository.GetAll();

            Assert.True(result.Count > 0);
        }
    }
}
