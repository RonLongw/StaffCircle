﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using RepositoryCore.Interfaces;
using RepositoryCore.Model;

namespace RepositoryCoreTests.Repositories
{
    public class TwilioRepository : IRepository<TwilioAccount>, IRepositoryUpdate<TwilioAccount>
    {
        public long Add(TwilioAccount newEntity)
        {
            throw new NotImplementedException();
        }

        public TwilioAccount Find(Expression<Func<TwilioAccount, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        public List<TwilioAccount> GetAll()
        {
            throw new NotImplementedException();
        }

        public void Remove(TwilioAccount entity)
        {
            throw new NotImplementedException();
        }

        public long Update(TwilioAccount entity)
        {
            throw new NotImplementedException();
        }
    }
}
