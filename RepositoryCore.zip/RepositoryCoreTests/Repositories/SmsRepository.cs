﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using RepositoryCore.Interfaces;
using RepositoryCore.Model;

namespace RepositoryCoreTests.Repositories
{
    public class SmsRepository : IRepository<SmsMessage>
    {
        List<SmsMessage> messages = null;

        public SmsRepository()
        {
            messages = new List<SmsMessage>()
            {
                new SmsMessage() { Created = DateTime.Now, Id = 1, Message = "Hello everybody", Number = "0102020202002"},
                new SmsMessage() { Created = DateTime.Now, Id = 2, Message = "Goodbye everybody", Number = "01011188828"},
                new SmsMessage() { Created = DateTime.Now, Id = 3, Message = "Happy New Year", Number = "03494877757"},
                new SmsMessage() { Created = DateTime.Now, Id = 4, Message = "Easter is next", Number = "0293847775"},
                new SmsMessage() { Created = DateTime.Now, Id = 5, Message = "Then Halloween", Number = "0583774665"},
            };
        }

        public long Add(SmsMessage newEntity)
        {
            

            if (ValidateModel(newEntity))
            {
                var maxId = messages.Max(m => m.Id) + 1;

                newEntity.Id = maxId;
                messages.Add(newEntity);
            }
            else
            {
                newEntity.Id = 0;
            }
            
            return newEntity.Id;
        }

        public SmsMessage Find(Expression<Func<SmsMessage, bool>> predicate)
        {
            Func<SmsMessage, bool> func = predicate.Compile();
            bool pred(SmsMessage t) => func(t);

            var msg = messages.Find(pred);

            return msg;
        }

        public List<SmsMessage> GetAll()
        {
            return messages;
        }

        public void Remove(SmsMessage entity)
        {
            messages.Remove(entity);
        }

        //Could refactor this as it is reused in a number of places, but time is
        //the issue
        private bool ValidateModel(SmsMessage sms)
        {
            var result = true;

            if (string.IsNullOrEmpty(sms.Message))
            {
                return false;
            }

            if (string.IsNullOrEmpty(sms.Number))
            {
                return false;
            }

            if (DateTime.MinValue == sms.Created)
            {
                return false;
            }

            return result;

        }
    }
}
