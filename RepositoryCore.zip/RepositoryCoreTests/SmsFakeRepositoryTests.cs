﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using RepositoryCore.Model;
using RepositoryCoreTests.Repositories;
using Xunit;

namespace RepositoryCoreTests
{
    public class SmsFakeRepositoryTests
    {
        [Fact]
        public void InsertSmsMessage()
        {
            var message = new SmsMessage()
            {
                Number = "12345678",
                Message = "The rain in Spain stays mainly on the plain.",
                Created = DateTime.Now
            };

            var repository = new SmsRepository();
            var result = repository.Add(message);

            Debug.WriteLine($"Result Value: {result}");

            Assert.True(result > 0);
        }

        [Fact]
        public void InsertSmsMessageWithNoNumber()
        {
            var message = new SmsMessage()
            {
                Number = "",
                Message = "The rain in Spain stays mainly on the plain.",
                Created = DateTime.Now
            };

            var repository = new SmsRepository();
            var result = repository.Add(message);

            Debug.WriteLine($"Result Value: {result}");

            Assert.True(result == 0);
        }

        [Fact]
        public void InsertSmsMessageWithNoMessage()
        {
            var message = new SmsMessage()
            {
                Number = "098765432",
                Message = "",
                Created = DateTime.Now
            };

            var repository = new SmsRepository();
            var result = repository.Add(message);

            Debug.WriteLine($"Result Value: {result}");

            Assert.True(result == 0);
        }

        [Fact]
        public void InsertSmsMessageWithDateNotSet()
        {
            var message = new SmsMessage()
            {
                Number = "098765432",
                Message = "",
                //Created = DateTime.Now
            };

            var repository = new SmsRepository();
            var result = repository.Add(message);

            Debug.WriteLine($"Result Value: {result}");

            Assert.True(result == 0);
        }

        [Fact]
        public void GetSmsMessage()
        {
            var repository = new SmsRepository();

            var result = repository.Find(s => s.Id == 1);

            if (result != null)
            {
                var SmsId = result.Id;

                Assert.True(SmsId == 1);
            }
            else
            {
                Assert.False(result.Id != 1);
            }

        }

    }
}
