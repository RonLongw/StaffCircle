﻿using System;
using System.Diagnostics;
using Xunit;
using RepositoryCore.Repositories;
using RepositoryCore.Model;
using RepositoryCore.DataAccessLayer;
using Microsoft.EntityFrameworkCore;

namespace RepositoryTests
{
    public class SmsTests
    {
        private string conn = "Data Source=DESKTOP-IPPVKT1\\SQLEXPRESS;Initial Catalog=SMS;Integrated Security=True;Connect Timeout=30;Encrypt=False;";

        //private string conn = "Server = DESKTOP-IPPVKT1\\SQLEXPRESS; Database = SMS; Trusted_Connection = True; ";

        //[Fact]
        //public void InsertSmsMessageThrowsException()
        //{
        //    var optionsBuilder = new DbContextOptionsBuilder<SmsDbContext>();
        //    optionsBuilder.UseSqlServer(conn);

        //    var sms = new SmsDbContext(optionsBuilder.Options);
        //}

        [Fact]
        public void InsertSmsMessage()
        {
            var optionsBuilder = new DbContextOptionsBuilder<SmsDbContext>();
            optionsBuilder.UseSqlServer(conn);

            var message = new SmsMessage()
            {
                Number = "12345678",
                Message = "The rain in Spain stays mainly on the plain.",
                Created = DateTime.Now
            };

            var context = new SmsDbContext(optionsBuilder.Options);

            var repository = new EFSmsMessageRepository(context);
            var result = repository.Add(message);

            Debug.WriteLine($"Result Value: {result}");
            
            Assert.True(result > 0);
        }

        [Fact]
        public void InsertSmsMessageWithNoNumber()
        {
            var optionsBuilder = new DbContextOptionsBuilder<SmsDbContext>();
            optionsBuilder.UseSqlServer(conn);

            var message = new SmsMessage()
            {
                Number = "",
                Message = "The rain in Spain stays mainly on the plain.",
                Created = DateTime.Now
            };

            var context = new SmsDbContext(optionsBuilder.Options);

            var repository = new EFSmsMessageRepository(context);
            var result = repository.Add(message);

            Debug.WriteLine($"Result Value: {result}");

            Assert.True(result == 0);
        }

        [Fact]
        public void InsertSmsMessageWithNoMessage()
        {
            var optionsBuilder = new DbContextOptionsBuilder<SmsDbContext>();
            optionsBuilder.UseSqlServer(conn);

            var message = new SmsMessage()
            {
                Number = "098765432",
                Message = "",
                Created = DateTime.Now
            };

            var context = new SmsDbContext(optionsBuilder.Options);

            var repository = new EFSmsMessageRepository(context);
            var result = repository.Add(message);

            Debug.WriteLine($"Result Value: {result}");

            Assert.True(result == 0);
        }

        [Fact]
        public void InsertSmsMessageWithDateNotSet()
        {
            var optionsBuilder = new DbContextOptionsBuilder<SmsDbContext>();
            optionsBuilder.UseSqlServer(conn);

            var message = new SmsMessage()
            {
                Number = "098765432",
                Message = "",
                //Created = DateTime.Now
            };

            var context = new SmsDbContext(optionsBuilder.Options);

            var repository = new EFSmsMessageRepository(context);
            var result = repository.Add(message);

            Debug.WriteLine($"Result Value: {result}");

            Assert.True(result == 0);
        }

        [Fact]
        public void GetSmsMessage()
        {
            var optionsBuilder = new DbContextOptionsBuilder<SmsDbContext>();
            optionsBuilder.UseSqlServer(conn);

            var context = new SmsDbContext(optionsBuilder.Options);

            var repository = new EFSmsMessageRepository(context);
            var result = repository.Find(s => s.Id == 1);

            if (result != null)
            {
                var SmsId = result.Id;

                Assert.True(SmsId == 1);
            }
            else
            {
                Assert.False(result.Id != 1);
            }
            
        }
    }
}
