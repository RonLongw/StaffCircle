﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using RepositoryCore.Model;

namespace RepositoryCore.DataAccessLayer
{
    public class SmsDbContext : DbContext
    {
        public SmsDbContext(DbContextOptions<SmsDbContext> options) : base(options)
        { }

        public DbSet<SmsMessage> SmsMessages { get; set; }
        public DbSet<TwilioAccount> TwilioAccounts { get; set; }

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer(
        //         "Server = (localdb)\\mssqllocaldb; Database = SMS; Trusted_Connection = True; ");
        //}
    }
}
