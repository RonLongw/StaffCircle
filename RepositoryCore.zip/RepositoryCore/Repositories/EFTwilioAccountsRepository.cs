﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using RepositoryCore.DataAccessLayer;
using RepositoryCore.Interfaces;
using RepositoryCore.Model;

namespace RepositoryCore.Repositories
{
    public class EFTwilioAccountsRepository : IRepository<TwilioAccount>, IRepositoryUpdate<TwilioAccount>
    {
        private SmsDbContext context;

        public EFTwilioAccountsRepository(SmsDbContext ctx)
        {
            context = ctx;
        }

        public long Add(TwilioAccount newEntity)
        {
            try
            {
                if (ValidateModel(newEntity))
                {
                    context.Add(newEntity);
                    context.SaveChanges();
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception exc)
            {
                var msg = exc.Message;
                return 0;
            }

            return newEntity.Id;
        }

        public TwilioAccount Find(Expression<Func<TwilioAccount, bool>> predicate)
        {
            return context.TwilioAccounts.Where(predicate).FirstOrDefault<TwilioAccount>();
        }

        public void Remove(TwilioAccount entity)
        {
            try
            {
                context.Remove(entity);
                context.SaveChanges();
            }
            catch
            {
                throw new Exception($"Failed to remove Twilio Account details wih Id {entity.Id}");
            }
        }

        public long Update(TwilioAccount entity)
        {
            try
            {
                if (ValidateModel(entity))
                {
                    context.Update(entity);
                    context.SaveChanges();
                }
                else
                {
                    return 0;
                }
            }
            catch
            {
                return 0;
            }

            return entity.Id;
            

        }

        public IQueryable<TwilioAccount> TwilioAccounts => context.TwilioAccounts;

        private bool ValidateModel(TwilioAccount twilio)
        {
            var result = true;

            if (string.IsNullOrEmpty(twilio.AccountSid))
            {
                return false;
            }

            if (string.IsNullOrEmpty(twilio.AuthToken))
            {
                return false;
            }

            if (DateTime.MinValue == twilio.Created)
            {
                return false;
            }

            return result;

        }

        public List<TwilioAccount> GetAll()
        {
            return TwilioAccounts.ToList();
        }
    }
}
