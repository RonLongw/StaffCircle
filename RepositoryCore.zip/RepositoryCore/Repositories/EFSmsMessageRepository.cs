﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using RepositoryCore.DataAccessLayer;
using RepositoryCore.Model;
using RepositoryCore.Interfaces;

namespace RepositoryCore.Repositories
{
    public class EFSmsMessageRepository : IRepository<SmsMessage>
    {
        private SmsDbContext context;

        public EFSmsMessageRepository(SmsDbContext ctx)
        {
            context = ctx;
        }

        public long Add(SmsMessage newEntity)
        {
            try
            {
                if (ValidateModel(newEntity))
                {
                    context.Add(newEntity);
                    context.SaveChanges();
                }
                else
                {
                    return 0;
                }
                
            }
            catch (Exception exc)
            {
                var msg = exc.Message;
                return 0;
            }
            
            return newEntity.Id;
        }

        public SmsMessage Find(Expression<Func<SmsMessage, bool>> predicate)
        {
            return context.SmsMessages.Where(predicate).FirstOrDefault<SmsMessage>();                   
        }

        public void Remove(SmsMessage entity)
        {
            context.Remove(entity);
        }

        public IQueryable<SmsMessage> SmsMessages => context.SmsMessages;

        private bool ValidateModel(SmsMessage sms)
        {
            var result = true;

            if (string.IsNullOrEmpty(sms.Message))
            {
                return false;
            }

            if (string.IsNullOrEmpty(sms.Number))
            {
                return false;
            }

            if (DateTime.MinValue == sms.Created)
            {
                return false;
            }

            return result;

        }

        public IQueryable<SmsMessage> AllMessages => context.SmsMessages;

        public List<SmsMessage> GetAll()
        {
            return AllMessages.ToList();
        }
    }
}
