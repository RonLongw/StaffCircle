﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace RepositoryCore.Interfaces
{
    public interface IRepository<T>
    {
        long Add(T newEntity);
        void Remove(T entity);
        T Find(Expression<Func<T, bool>> predicate);
        List<T> GetAll();
    }
}
