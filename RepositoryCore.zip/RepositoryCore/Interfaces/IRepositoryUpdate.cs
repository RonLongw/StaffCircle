﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RepositoryCore.Interfaces
{
    public interface IRepositoryUpdate<T>
    {
        long Update(T entity);
    }
}
